import { useState, useEffect } from 'react'
import { checkStatus } from '../hooks/useApi'

export default function StatusBar() {
  const [status, setStatus] = useState(null)
  const [error, setError] = useState(false)

  useEffect(() => {
    const fetch_ = async () => {
      try {
        const s = await checkStatus()
        setStatus(s)
        setError(false)
      } catch {
        setError(true)
      }
    }
    fetch_()
    const id = setInterval(fetch_, 15000)
    return () => clearInterval(id)
  }, [])

  const dot = (on, label, color) => (
    <span style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 11, color: on ? color : 'var(--text-muted)' }}>
      <span style={{
        width: 6, height: 6, borderRadius: '50%',
        background: on ? color : 'var(--text-muted)',
        animation: on ? 'pulse-dot 2s ease infinite' : 'none'
      }} />
      {label}
    </span>
  )

  return (
    <div style={{
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      padding: '8px 24px', borderBottom: '1px solid var(--border)',
      background: 'var(--bg-card)', fontSize: 11,
      fontFamily: 'var(--font-mono)', color: 'var(--text-secondary)'
    }}>
      <span style={{ color: 'var(--text-muted)' }}>priyansh@agent:~$</span>
      <div style={{ display: 'flex', gap: 20 }}>
        {error
          ? dot(false, 'backend offline', 'var(--red)')
          : status ? (
            <>
              {dot(true, status.ai_provider === 'anthropic' ? 'claude' : 'gemini', 'var(--green)')}
              {dot(status.linkedin_connected, 'linkedin', 'var(--accent)')}
              <span style={{ color: 'var(--text-muted)' }}>
                model: {status.ai_model || '—'}
              </span>
            </>
          ) : dot(false, 'connecting...', 'var(--amber)')}
      </div>
    </div>
  )
}
