# 🤖 Priyansh's LinkedIn AI Agent — Full Stack

> DevOps-native LinkedIn automation: React frontend + FastAPI backend + Docker

---

## 📁 Project Structure

```
linkedin-agent/
├── backend/
│   ├── main.py              ← FastAPI app (all 3 modes + LinkedIn API)
│   ├── requirements.txt     ← Python deps
│   └── Dockerfile
├── frontend/
│   ├── src/
│   │   ├── App.jsx          ← Main app + routing
│   │   ├── components/
│   │   │   ├── StatusBar.jsx    ← Live AI + LinkedIn status
│   │   │   ├── Sidebar.jsx      ← Navigation
│   │   │   └── OutputPanel.jsx  ← Generated content + post button
│   │   ├── pages/
│   │   │   ├── ContentPage.jsx  ← Work activity → LinkedIn post
│   │   │   ├── BrandPage.jsx    ← Events/hackathons → brand post
│   │   │   └── JobPage.jsx      ← JD → cover letter + recruiter DM
│   │   └── hooks/
│   │       └── useApi.js        ← All backend API calls
│   ├── Dockerfile
│   ├── package.json
│   └── vite.config.js
├── step1_get_token.py       ← Run ONCE to connect LinkedIn (from prev version)
├── docker-compose.yml
├── .env                     ← Your secrets (never commit!)
├── .gitignore
└── README.md
```

---

## ⚡ Quick Start (Docker — Recommended)

### Step 1 — Fill in your `.env` file

Open `.env` and add your keys:

```env
GEMINI_API_KEY=your_gemini_key_here           # Get from aistudio.google.com
ANTHROPIC_API_KEY=your_anthropic_key_here     # Get from console.anthropic.com (optional)
LINKEDIN_CLIENT_ID=8686ysfd1dxz4r             # Already filled
LINKEDIN_CLIENT_SECRET=your_secret_here       # From LinkedIn Developer app → Auth tab
LINKEDIN_ACCESS_TOKEN=                        # Auto-filled by step1_get_token.py
LINKEDIN_PERSON_URN=                          # Auto-filled by step1_get_token.py
```

> **Priority rule:** If both AI keys are set, Anthropic Claude is used. If only Gemini is set, Gemini is used.

### Step 2 — Connect your LinkedIn account (run ONCE)

```bash
# Install dependencies first (only needed for this step)
pip install requests python-dotenv

# Run the OAuth flow — opens your browser
python step1_get_token.py
```

This saves your `LINKEDIN_ACCESS_TOKEN` and `LINKEDIN_PERSON_URN` into `.env` automatically.

### Step 3 — Start with Docker

```bash
docker-compose up --build
```

That's it. Open your browser:

| Service  | URL                        |
|----------|----------------------------|
| Frontend | http://localhost:3000       |
| Backend  | http://localhost:8000       |
| API Docs | http://localhost:8000/docs  |

---

## 🔧 Running Without Docker (Local Dev)

### Backend
```bash
cd backend
pip install -r requirements.txt
uvicorn main:app --reload --port 8000
```

### Frontend
```bash
cd frontend
npm install
npm run dev
```

---

## 🎯 How to Use the UI

### 1. Content Mode (`✦`)
- Tell your agent what you did at work in plain words
- Example: *"Today I migrated a 3TB MongoDB cluster from OneApp to OneMind account with zero downtime..."*
- Agent generates a viral LinkedIn post with hook → story → insight → hashtags
- Review → click **Post to LinkedIn**

### 2. Brand Mode (`◈`)
- Describe events, hackathons, certifications, talks
- Example: *"I participated in DT's Cost Smash challenge and presented 3 infrastructure cost-saving ideas..."*
- Agent positions you as a thought leader with a story-driven post

### 3. Job Hunt Mode (`⊕`)
- Paste any job description from LinkedIn / Naukri / company site
- Agent generates:
  - **Cover letter** (3 paragraphs: technical fit → culture fit → confident close)
  - **8 resume keywords** to add to your resume
  - **Recruiter DM** (5 sentences, mentions DT + FIFA 2026 infra)

---

## 🔑 Getting Your API Keys

### Gemini (Free)
1. Go to [aistudio.google.com](https://aistudio.google.com)
2. Click **Get API Key** → Create API key
3. Paste into `.env` as `GEMINI_API_KEY`

### Anthropic Claude (Paid, better quality)
1. Go to [console.anthropic.com](https://console.anthropic.com)
2. API Keys → Create Key → Add $5 credit
3. Paste into `.env` as `ANTHROPIC_API_KEY`

---

## 🐳 Docker Commands Cheatsheet

```bash
# Start everything
docker-compose up --build

# Start in background
docker-compose up -d --build

# View logs
docker-compose logs -f

# View only backend logs
docker-compose logs -f backend

# Stop everything
docker-compose down

# Rebuild after code changes
docker-compose up --build

# Check container status
docker-compose ps
```

---

## 🔌 Backend API Endpoints

| Method | Endpoint             | Description                        |
|--------|---------------------|------------------------------------|
| GET    | `/health`            | Health check + provider status     |
| GET    | `/status`            | AI provider + LinkedIn connection  |
| POST   | `/generate`          | Generate content (all 3 modes)     |
| POST   | `/post-to-linkedin`  | Post text to your LinkedIn profile |

Full interactive docs: **http://localhost:8000/docs**

### Example API call:
```bash
curl -X POST http://localhost:8000/generate \
  -H "Content-Type: application/json" \
  -d '{
    "mode": "content",
    "input": "Today I migrated a 3TB MongoDB cluster to a new account with zero downtime"
  }'
```

---

## ⚠️ Important Notes

- **Never commit `.env`** — it contains your API keys and LinkedIn token
- **LinkedIn token expires every 2 months** — re-run `step1_get_token.py` when it does
- **Always review posts before confirming** — the agent generates, you approve
- **Target companies** are product-based only (no IT services / consulting firms)

---

## 🧱 Tech Stack

| Layer      | Technology          | Version  |
|------------|---------------------|----------|
| Frontend   | React + Vite        | 18 / 5.x |
| Styling    | CSS Variables + Inline | —     |
| Backend    | FastAPI             | 0.115.x  |
| Server     | Uvicorn             | 0.30.x   |
| AI (free)  | Google Gemini       | 2.5 Flash|
| AI (paid)  | Anthropic Claude    | Sonnet 4 |
| Container  | Docker + Compose    | v3.9     |

---

*Built for Priyansh Saxena — DevOps & Platform Engineer @ Deutsche Telekom Digital Labs 🚀*
