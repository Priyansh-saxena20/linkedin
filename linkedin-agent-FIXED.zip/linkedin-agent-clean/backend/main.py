from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import requests
import os
from dotenv import load_dotenv
from datetime import datetime
from typing import Optional

load_dotenv()

app = FastAPI(title="Priyansh LinkedIn Agent API", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000", "http://frontend:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── ENV ──────────────────────────────────────────────────
GEMINI_API_KEY      = os.getenv("GEMINI_API_KEY", "")
ANTHROPIC_API_KEY   = os.getenv("ANTHROPIC_API_KEY", "")
LINKEDIN_TOKEN      = os.getenv("LINKEDIN_ACCESS_TOKEN", "")
LINKEDIN_PERSON_URN = os.getenv("LINKEDIN_PERSON_URN", "")

# ── SYSTEM PROMPT ─────────────────────────────────────────
SYSTEM_PROMPT = """
You are Priyansh's Personal LinkedIn AI Agent — a skilled technical writer,
marketing strategist, and job search specialist.

=== ABOUT PRIYANSH ===
Name: Priyansh Saxena | Role: DevOps & Platform Engineer
Company: Deutsche Telekom Digital Labs | Experience: 2+ years
Skills: Kubernetes, Istio, AWS, GCP, Terraform, CI/CD, VictoriaMetrics,
Grafana, MongoDB Operators, RabbitMQ, Docker, Jenkins, Python, Bash
Certs: RHCSA, Red Hat Ansible RH294, Red Hat Containers DO180, IBM Cloud
Key highlights: FIFA 2026 World Cup infra, 3TB MongoDB zero-downtime migration,
Istio service mesh implementation, AWS migration of 42 enterprise apps

=== CONTENT RULES ===
- Write like a MARKETING STRATEGIST selling Priyansh's skills — not a resume bot
- Posts: Hook → Story (Problem/Action/Result) → Insight → CTA → Hashtags
- Hook must make people STOP SCROLLING in the first 2 lines
- Real numbers, real tools, real outcomes — never fabricate anything
- Max 3-4 emojis, 5-7 hashtags, 150-250 words per post
- ALWAYS end every LinkedIn post with: — Posted by Priyansh's Personal AI Agent 🤖

=== JOB PREFERENCES ===
- Product-based companies ONLY — no IT services, no consulting firms
- Target: Hotstar, JP Morgan, Apple, Zscaler, Cloudflare, HashiCorp, Datadog,
  Grafana Labs, MongoDB Inc, Red Hat, Palo Alto Networks, Razorpay, CRED, PhonePe
- Roles: DevOps Engineer, Platform Engineer, SRE, Cloud Engineer
- Location: Remote/Hybrid preferred | Bangalore, Pune, Hyderabad, Delhi NCR
"""

# ── PROVIDER DETECTION ────────────────────────────────────
def get_provider():
    if ANTHROPIC_API_KEY and ANTHROPIC_API_KEY not in ("", "your_anthropic_api_key_here"):
        return "anthropic"
    elif GEMINI_API_KEY and GEMINI_API_KEY not in ("", "your_new_gemini_api_key_here"):
        return "gemini"
    return None

# ── AI CALLS ──────────────────────────────────────────────
def call_gemini(prompt: str) -> str:
    url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key={GEMINI_API_KEY}"
    payload = {
        "system_instruction": {"parts": [{"text": SYSTEM_PROMPT}]},
        "contents": [{"role": "user", "parts": [{"text": prompt}]}],
        "generationConfig": {"temperature": 0.85, "maxOutputTokens": 1024}
    }
    r = requests.post(url, headers={"Content-Type": "application/json"}, json=payload)
    if r.status_code != 200:
        raise HTTPException(status_code=502, detail=f"Gemini error: {r.text}")
    return r.json()["candidates"][0]["content"]["parts"][0]["text"]

def call_anthropic(prompt: str) -> str:
    headers = {
        "x-api-key": ANTHROPIC_API_KEY,
        "anthropic-version": "2023-06-01",
        "content-type": "application/json"
    }
    payload = {
        "model": "claude-sonnet-4-20250514",
        "max_tokens": 1024,
        "system": SYSTEM_PROMPT,
        "messages": [{"role": "user", "content": prompt}]
    }
    r = requests.post("https://api.anthropic.com/v1/messages", headers=headers, json=payload)
    if r.status_code != 200:
        raise HTTPException(status_code=502, detail=f"Anthropic error: {r.text}")
    return r.json()["content"][0]["text"]

def ask_ai(prompt: str) -> str:
    provider = get_provider()
    if provider == "anthropic":
        return call_anthropic(prompt)
    elif provider == "gemini":
        return call_gemini(prompt)
    raise HTTPException(status_code=500, detail="No valid AI API key configured in .env")

# ── SCHEMAS ───────────────────────────────────────────────
class GenerateRequest(BaseModel):
    mode: str  # "content" | "brand" | "job"
    input: str

class PostRequest(BaseModel):
    text: str

# ── PROMPT BUILDERS ───────────────────────────────────────
def build_prompt(mode: str, user_input: str) -> str:
    if mode == "content":
        return f"""MODE: CONTENT
Convert this activity into a viral LinkedIn post.
Rules:
- Powerful hook — first 2 lines must stop scrolling
- Structure: Problem → What I did → How → Result
- Include real technical details (tools, numbers, outcomes)
- End with a key insight OR question for the community
- 5-7 hashtags, 150-250 words total
- Final line MUST be: — Posted by Priyansh's Personal AI Agent 🤖

Activity:
{user_input}"""

    elif mode == "brand":
        return f"""MODE: BRAND
Create a thought-leadership LinkedIn post about this event or achievement.
Rules:
- Tell the STORY — don't just announce it
- Connect it to a bigger industry trend
- Highlight what made Priyansh's contribution unique
- End with a bold insight or thought-provoking question
- Format: Hook → Story → Insight → CTA → Hashtags
- Final line MUST be: — Posted by Priyansh's Personal AI Agent 🤖

Event/Achievement:
{user_input}"""

    elif mode == "job":
        return f"""MODE: JOB HUNT
Analyze this Job Description and generate all 3 items:

1. COVER LETTER (3 paragraphs):
   - Para 1: Technical fit — match my skills directly to the JD
   - Para 2: Culture/mission fit — why this company specifically
   - Para 3: Confident closing with a clear call to action

2. RESUME KEYWORDS:
   List the top 8 keywords from this JD I should add to my resume

3. RECRUITER MESSAGE (LinkedIn DM, max 5 sentences):
   - Mention Deutsche Telekom + FIFA 2026 infra as credibility signal
   - Name the specific role
   - End with a low-friction ask (15-min call or referral)
   - Confident, direct, not copy-paste sounding

My profile: 2+ years DevOps/Platform at Deutsche Telekom. FIFA 2026 infra prep,
3TB MongoDB migration, Istio mesh. RHCSA certified. AWS + GCP experienced.

Job Description:
{user_input}"""

    raise HTTPException(status_code=400, detail=f"Unknown mode: {mode}")

# ── ROUTES ────────────────────────────────────────────────
@app.get("/health")
def health():
    provider = get_provider()
    return {
        "status": "ok",
        "provider": provider or "none",
        "linkedin_connected": bool(LINKEDIN_TOKEN),
        "timestamp": datetime.now().isoformat()
    }

@app.post("/generate")
def generate(req: GenerateRequest):
    prompt = build_prompt(req.mode, req.input)
    result = ask_ai(prompt)
    return {"result": result, "mode": req.mode}

@app.post("/post-to-linkedin")
def post_to_linkedin(req: PostRequest):
    if not LINKEDIN_TOKEN:
        raise HTTPException(status_code=400, detail="LinkedIn not connected. Run step1_get_token.py first.")
    if not LINKEDIN_PERSON_URN:
        raise HTTPException(status_code=400, detail="LinkedIn URN not configured.")

    headers = {
        "Authorization": f"Bearer {LINKEDIN_TOKEN}",
        "Content-Type": "application/json",
        "X-Restli-Protocol-Version": "2.0.0"
    }
    payload = {
        "author": LINKEDIN_PERSON_URN,
        "lifecycleState": "PUBLISHED",
        "specificContent": {
            "com.linkedin.ugc.ShareContent": {
                "shareCommentary": {"text": req.text},
                "shareMediaCategory": "NONE"
            }
        },
        "visibility": {"com.linkedin.ugc.MemberNetworkVisibility": "PUBLIC"}
    }
    r = requests.post("https://api.linkedin.com/v2/ugcPosts", headers=headers, json=payload)
    if r.status_code == 201:
        return {"success": True, "posted_at": datetime.now().isoformat()}
    raise HTTPException(status_code=502, detail=f"LinkedIn post failed: {r.text}")

@app.get("/status")
def status():
    provider = get_provider()
    return {
        "ai_provider": provider,
        "ai_model": "claude-sonnet-4" if provider == "anthropic" else "gemini-2.5-flash" if provider == "gemini" else None,
        "linkedin_connected": bool(LINKEDIN_TOKEN and LINKEDIN_PERSON_URN),
        "linkedin_urn": LINKEDIN_PERSON_URN if LINKEDIN_PERSON_URN else None,
    }
